package com.example.micromanager_datamanager

import java.util.*

class TTSManager{
    var TTSQueue : Queue<String> = LinkedList<String>() //가공된 data
    var FocusQueue : Queue<String> = LinkedList<String>() //집중모드일때 쌓이고, 먼저 말해줄 data

    fun TTSPushQueue(subtitle:String,message:String) : Unit{ //TTS Queue에 설정한 형식에 맞는 가공된 메세지 넣기
        TTSQueue.add(message)
    }
    fun FocusPushQueue(subtitle:String,message:String) : Unit{ //Focus Queue에 설정한 형식에 맞는 가공된 메세지 넣기
        FocusQueue.add(message)
    }
}

