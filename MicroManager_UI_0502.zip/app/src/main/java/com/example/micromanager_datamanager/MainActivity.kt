package com.example.micromanager_datamanager

import android.media.Image
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.micromanager_datamanager.databinding.ActivityMainBinding
import com.example.micromanager_datamanager.databinding.MicromanagerMainBinding
import com.example.micromanager_datamanager.databinding.MicromanagerReplayBinding

import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private lateinit var bindingMain: MicromanagerMainBinding //메인화면 binding
    private lateinit var bindingReplay: MicromanagerReplayBinding //다시듣기 binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()

        }
        val replay_layout = findViewById<LinearLayout>(R.id.replay_layout)
        val replay_View = LayoutInflater.from(this).inflate(R.layout.micromanager_replay,null,false)
        // 뷰에 대해서 findViewById로 접근
        val replay_title = replay_View.findViewById<TextView>(R.id.replay_title).text
        val replay_message = replay_View.findViewById<TextView>(R.id.replay_message).text
        val replay_button = replay_View.findViewById<Button>(R.id.replay_button)
        //replay layout 띄우기
        replay_layout.addView(replay_View)
        /*
        replay_button.setOnClickListener{
            Toast.makeText(this@MainActivity, "이 메세지를 다시 듣습니다.", Toast.LENGTH_SHORT).show()
            //tts로 연결해서 읽어주기
        }
         */
        bindingReplay.replayButton.setOnClickListener(replay_listener)

        //버튼
        val distrub_event = findViewById<ImageButton>(R.id.DistrubButton)
        val focus_event = findViewById<ImageButton>(R.id.FocusButton)
        val text_event = findViewById<ImageButton>(R.id.TextButton)
        distrub_event.setOnClickListener{
            Toast.makeText(this@MainActivity, "방해금지 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //방해금지 메소드 연결 필요
        }
        focus_event.setOnClickListener{
            Toast.makeText(this@MainActivity, "집중모드 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //집중모드 메소드 연결 필요
        }
        text_event.setOnClickListener{
            Toast.makeText(this@MainActivity, "메시지 설정 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //메시지 문구 설정 메소드 연결 필요
        }
        /*
        //동적버튼
        val view = bindingMain.root
        setContentView(view)
        //버튼 리스너 설정, guild.gradle에 buildFeatures 추가
        bindingMain.DistrubButton.setOnClickListener(listener1)
        bindingMain.FocusButton.setOnClickListener(listener2)
        bindingMain.TextButton.setOnClickListener(listener3)
        */


    }
    val replay_listener = View.OnClickListener {
        bindingReplay.replayButton
        Toast.makeText(this@MainActivity, "메세지 다시듣기 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
    }
    /*
    val listener1 = View.OnClickListener {
        bindingMain.textView1.text = "첫 번째 버튼을 눌렀습니다."
        Toast.makeText(this@MainActivity, "방해금지 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
    }

    val listener2 = View.OnClickListener {
        bindingMain.textView1.text = "두 번째 버튼을 눌렀습니다."
        Toast.makeText(this@MainActivity, "집중모드 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
    }
    val listener3 = View.OnClickListener {
        bindingMain.textView1.text = "두 번째 버튼을 눌렀습니다."
        Toast.makeText(this@MainActivity, "메시지 설정 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
    }
    */

    /*
    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.DistrubButton->{
                Toast.makeText(this@MainActivity, "방해금지 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            }
            R.id.FocusButton->{
                Toast.makeText(this@MainActivity, "집중모드 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            }
            R.id.TextButton->{
                Toast.makeText(this@MainActivity, "카톡방 지정 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    */
/*
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        for(id in 1 until 3){
            val normalBtn3 = Button(this).apply{
                width = getDPI(200)
                height = getDPI(200)
                setOnClickListener{
                    btnAction(id)
                }
            }

            bodyView.addView(normalBtn3)
        }
    }

    fun btnAction(id: Int){
        when(id){
            1 ->{//방해금지
                Toast.makeText(this, "${id}버튼이 클릭되었습니다",Toast.LENGTH_LONG).show()
            }
            2 ->{//집중
                Toast.makeText(this, "${id}버튼이 클릭되었습니다",Toast.LENGTH_LONG).show()
            }
            3 ->{//문구입력
                Toast.makeText(this, "${id}버튼이 클릭되었습니다",Toast.LENGTH_LONG).show()
            }
        }
    }
    fun getDPI(dp:Int):Int{
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics.to)
    }
*/
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }

}