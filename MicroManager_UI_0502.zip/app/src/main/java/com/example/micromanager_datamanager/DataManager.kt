package com.example.micromanager_datamanager

import java.util.*

class DataManager {
    var IsDistrub : Boolean = false //방해금지 모드 true : on, false : off
    var IsFocus : Boolean = false //집중모드 true : on, false : off
    var DataQueue : Queue<String> = LinkedList<String>() //raw data
    //var TTSQueue : Queue<String> = LinkedList<String>() //가공된 data -> tts queue에 생성
    var FocusQueue : Queue<String> = LinkedList<String>() //지정한 카톡방의 메세지를 담는 queue
    var FocusTitle : String = "지정한 카톡방 이름"
    val Focusbtn : Boolean = false // 집중버튼 true : 클릭됨, false : 클릭해제

    fun InDataQueue(message:String) : Unit{ //Data Queue에 notification listener가 읽어온 메세지 넣기
        DataQueue.add(message)
    }

    fun OutDataQueue() : String{ //Data Queue에서 메세지 꺼내오기
        var message : String = "init"

        message = DataQueue.peek() as String
        DataQueue.remove()
        return message
    }
    fun InTTSQueue() : String{ //메세지 가공해서 TTSQueue에 넣기
        var rawmessage : String = "init"
        var manufacturmessage : String = "누구 입니다. 내용"

        rawmessage = OutDataQueue()//data queue에 있던 내용 rawmessage로 가져오기
        manufacturmessage = ManufactureMessage(rawmessage)// raw message tts로 출력할 형식에 맞춰서 수정

        print(manufacturmessage)
        return manufacturmessage
    }

    fun InFocusQueue(title : String, message:String) : String{ //title : 집중할 카톡방 이름
        var rawmessage : String = "init"
        var manufacturemessage : String = "누구 입니다. 내용"

        rawmessage = OutDataQueue() //
        manufacturemessage = ManufactureMessage(rawmessage)

        FocusQueue.add(manufacturemessage)//focus queue로 집어넣기
        return manufacturemessage
    }

    fun OutFocusQueue() : String{ //Focus Queue에서 메세지 꺼내오기
        var message : String = "init"

        message = FocusQueue.peek() as String
        DataQueue.remove()
        return message
    }

    fun ModifyFocusTitle(newFocusTitle:String):String{
        print("집중할 카톡방 입력")
        FocusTitle = newFocusTitle
        return FocusTitle
    }

    fun ManufactureMessage(rawmessage : String) : String{
        var token : List<String> = mutableListOf("postTime^ title^ subtitle^ message")
        var postTime : String = "123456"
        var title : String = "카톡방이름"
        var subtitle : String = "보낸사람" //카톡방 이름 없을때 null값 = 갠톡
        var message : String = "message"
        var manufacturemessage : String = "누구 입니다. 내용"

        token = rawmessage.split("^"); // , -> ^
        postTime = token[0]
        title = token[1]
        subtitle = token[2]
        message = token[3]

        if(title.equals(null)) { //갠톡처리
            title=subtitle
        }
        manufacturemessage = "%s 입니다. %s".format(subtitle, message)
        return manufacturemessage
    }

}
fun main(){//방해금지 설정
    //val TTSObject = TTSManager()
    val dm = DataManager() //dm -> tm.TsPushQueue
    val tm = TTSManager()
    var focusTitleName : String = "지정한 카톡방 이름"
    val title : String = "카톡방 이름"
    var message : String = "postTime^ title^ subtitle^ message"
    
    if (dm.Focusbtn) {//집중할 카톡방 이름 변경
        focusTitleName = dm.ModifyFocusTitle("")
        print("집중할 카톡방 이름 : %s".format(focusTitleName))
    }
    
    if (!dm.IsDistrub) {//방해금지가 아니라면
        message = dm.InTTSQueue() //가공된 메세지 data queue에서 가져오기
        tm.TTSPushQueue(title,message) // 이름변경 --> tm.TTSPushQueue // tts queue에 집어넣을 메세지 가져오기, 카톡방 이름인 title 매개변수로 줌
    }
    if (dm.IsFocus){//집중모드라면
        if(dm.FocusTitle==title) {//지정한 채팅방 이름의 메세지들을 focus queue에 집어넣음
            message = dm.InFocusQueue(title,message) //focus queue에 메세지 집어넣기
            tm.FocusPushQueue(title,message)
        }
    }
}