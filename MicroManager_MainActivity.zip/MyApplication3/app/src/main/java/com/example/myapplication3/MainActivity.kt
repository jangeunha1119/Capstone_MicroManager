package com.example.myapplication3


import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.telephony.SmsManager
import android.util.Log
import android.view.View
import android.widget.AdapterView.OnItemClickListener
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.util.*


class MainActivity : AppCompatActivity(), OnInitListener {
    var tts: TextToSpeech? = null
    var sttr = ""
    var resttr = ""
    var count=0
    val dm = DataManager()
    var movieDataList: ArrayList<SampleData>? = null

    var searchString = "정상화"

    private var dataList: ArrayList<Map<String, String>>? = null

    val clist: ArrayList<String> = arrayListOf<String>("지구와태양사이명왕성")
    
    var distrub_state: Boolean = false //방해금지 버튼 상태
    var focus_state: Boolean = false //다시듣기 버튼 상태
    var replay_state: Boolean = true
    var messagTx = "지금은 운전중이라 다음에 연락드리겠습니다."
    var phoneNum: String = ""
    var str = "개인 카톡"

    var focus_subText: String? = null
    var focus_title: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        InitializeMovieData()


        LocalBroadcastManager.getInstance(this).registerReceiver(onNotice, IntentFilter("Msg"))

        tts = TextToSpeech(this@MainActivity, this)

        if (!permissionGrantred()) {
            val intent = Intent(
                "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"
            )
            startActivity(intent)
        }

        ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.SEND_SMS,Manifest.permission.READ_CONTACTS), 100)



        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            var numbb = getPhoneNumber(searchString, this)
            if (numbb != null) {
                numbb = reNum(numbb)
            }
            Log.d("display name", numbb ?: "NotFound")
        }





        val distrub_event = findViewById<ImageButton>(R.id.DistrubButton)
        val focus_event = findViewById<ImageButton>(R.id.FocusButton)
        val text_event = findViewById<ImageButton>(R.id.TextButton)



        distrub_event.setOnClickListener {

            distrub_state = !distrub_state //true -> false, false -> true로
            if (distrub_state) {//distrub_state true 라면
                tts!!.stop()
            }
            distrub_event.isSelected = !distrub_event.isSelected
        }



        focus_event.setOnClickListener {

            if (!focus_state && replay_state) {
                replay_state = false
            } else if (!focus_state && !replay_state) {
                replay_state = true
            } else if (focus_state && replay_state) {
                focus_state = false
            }

            focus_event.isSelected = !focus_event.isSelected
        }


        /* text_event.setOnClickListener {
            Toast.makeText(this@MainActivity, "메시지 설정 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //메시지 문구 설정 메소드 연결 필요
        }*/



        text_event.setOnClickListener(View.OnClickListener {
            val ad: AlertDialog.Builder = AlertDialog.Builder(this@MainActivity)
            ad.setIcon(R.drawable.micromanager_icon)
            ad.setTitle("현재 답장 메시지 내용")
            ad.setMessage(messagTx);
            val et = EditText(this@MainActivity)
            ad.setView(et)
            ad.setPositiveButton("변경", DialogInterface.OnClickListener { dialog, which ->
                val result = et.text.toString()
                messagTx = result
                dialog.dismiss()
                clist.clear()
                clist.add("지구와태양사이명왕성")
            })
            ad.setNegativeButton("취소",
                DialogInterface.OnClickListener { dialog, which -> dialog.dismiss() })
            ad.show()
        })


    }

    private val onNotice: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {


            val listView = findViewById<View>(R.id.listView) as ListView
            val myAdapter = MyAdapter(this@MainActivity, movieDataList)


            val subText = intent.getStringExtra("subText")
            val title = intent.getStringExtra("title")
            val text = intent.getStringExtra("text")



            if (subText != null) {
                sttr = "$subText$title$text"
                movieDataList!!.add(0, SampleData("<$subText>", "$title", "$text"))
            } else {
                sttr = "$str$title$text"
                movieDataList!!.add(0, SampleData("<개인 카톡>", "$title", "$text"))

            }

            dm.InDataQueue("$subText", "$title", "$text")



            if (!distrub_state) {// distrub_state false일때 음성 출력

                if (focus_state) {
                    if (focus_title == null) {
                        if (focus_subText == "<$subText>") {
                            speakJust(sttr)
                            Toast.makeText(this@MainActivity, "집중 카톡방 : ${focus_subText}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else {
                        if (focus_title == title && subText == null) {
                            speakJust(sttr)
                            Toast.makeText(this@MainActivity, "집중 갠톡방 : ${focus_title}", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else
                    speakJust(sttr)
            }

            if (distrub_state){
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
                            && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                            if(subText==null){
                                if (cashcheck("$title")){
                                    clist.add("$title")
                                    var numThing = getPhoneNumber("$title", this@MainActivity)

                                    if (numThing != null) {
                                        numThing = reNum(numThing)
                                        phoneNum = numThing!!
                                        sendSMS()
                                    }
                                    else
                                        Toast.makeText(this@MainActivity, "번호가 없습니다", Toast.LENGTH_SHORT).show()
                                }
                                else
                                    Toast.makeText(this@MainActivity, "이미 메시지를 보냈습니다", Toast.LENGTH_SHORT).show()

                        }

                }
                        else {
                            //when permission is not granted
                            //request for permisiion
                            Toast.makeText(this@MainActivity, "권한이 없습니다", Toast.LENGTH_SHORT).show()
                            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS), 100
                            )
                        }


            }


            listView.adapter = myAdapter

            listView.onItemClickListener =
                OnItemClickListener { a_parent, a_view, a_position, a_id ->
                    val item: SampleData = myAdapter.getItem(a_position) as SampleData

                    if (!distrub_state) {
                        if (!replay_state) {
                            focus_state = true
                            if (item.poster != "<개인 카톡>") {
                                focus_subText = item.poster
                                focus_title = null
                                Toast.makeText(this@MainActivity, "${focus_subText}을 집중 카톡방 선택", Toast.LENGTH_SHORT).show()
                            } else {
                                focus_title = item.movieName
                                focus_subText = null
                                Toast.makeText(this@MainActivity, "${focus_title}을 집중 갠톡방 선택", Toast.LENGTH_SHORT).show()
                            }

                            replay_state = true
                        } else {
                            Toast.makeText(this@MainActivity, "음성 다시 재생", Toast.LENGTH_SHORT).show()
                            if (item.poster != null) {
                                resttr = "${item.poster}${item.movieName}${item.grade}"
                            } else {
                                resttr = "$str${item.movieName}${item.grade}"
                            }
                            tts!!.stop()
                            speakJust(resttr)
                        }
                    }
                }
        }


    }



    fun InitializeMovieData() {
        movieDataList = ArrayList()

    }


    override fun onDestroy() {

        // Don't forget to shutdown!
        if (tts != null) {
            tts!!.stop()
            tts!!.shutdown()
        }
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        // TODO Auto-generated method stub
        if (status == TextToSpeech.SUCCESS) {

            // 한국어 설정
            val result = tts!!.setLanguage(Locale.KOREAN)
            // tts.setPitch(5); // set pitch level
            // tts.setSpeechRate(2); // set speech speed rate

            // 한국어가 안된다면,
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Language is not supported")
            } else {
                Log.e("TTS", "Success")
            }
        } else {
            Log.e("TTS", "Initilization Failed")
        }
    }

    private fun permissionGrantred(): Boolean {
        val sets = NotificationManagerCompat.getEnabledListenerPackages(this)
        return if (sets != null && sets.contains(packageName)) {
            true
        } else {
            false
        }
    }

    fun speakJust(text: String?) {
        // tts가 사용중이면, 말하지않는다.
        tts!!.speak(text, TextToSpeech.QUEUE_ADD, null)
    }

    companion object {
        private const val TAG = "MainActivity"
    }


    private fun sendSMS() {
        //get value form editText
        var phone: String = phoneNum
        var message: String = messagTx

        //check condition if string is empty or not
        if (!phone.isEmpty() && !message.isEmpty()) {
            //initialize SMS Manager
            val smsManager: SmsManager = SmsManager.getDefault()
            //send message
            smsManager.sendTextMessage(phone, null, message, null, null)
            //display Toast msg
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show()
        } else {
            //when string is empty then display toast msg
            Toast.makeText(this, "Please enter phone and message", Toast.LENGTH_SHORT).show()
        }
    }


    fun getPhoneNumber(name: String, context: Context): String? {
        var ret: String? = null
        val selection =
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " like'%" + name + "%'"
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val c = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, selection, null, null
        )
        if (c!!.moveToFirst()) {
            ret = c.getString(0)
        }
        c.close()
        if (ret == null) ret = null
        return ret
    }


    fun reNum(n : String): String?{
        val numb = n.replace("-", "")
        return numb
    }

    fun cashcheck(subText: String): Boolean {

        for (str in clist) {
            if (subText == str) {
                return false
            }
        }

        return true
    }


}