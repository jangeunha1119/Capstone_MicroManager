package com.example.micromanager_datamanager

import java.util.*

class DataManager {
    var IsDistrub : Boolean = false //방해금지 모드 true : on, false : off
    var DataQueue : Queue<String> = LinkedList<String>() //raw data
    //var TTSQueue : Queue<String> = LinkedList<String>() //가공된 data -> tts queue에 생성

    fun InDataQueue(message:String) : Unit{ //Data Queue에 notification listener가 읽어온 메세지 넣기
        DataQueue.add(message)
    }
    fun OutDataQueue() : String{ //Data Queue에서 메세지 꺼내오기
        var message : String = "init"

        message = DataQueue.peek() as String
        DataQueue.remove()
        return message
    }
    fun InTTSQueue() : String{ //메세지 가공해서 TTSQueue에 넣기
        var rawmessage : String = "init"
        var token : List<String> = mutableListOf("postTime^ title^ subtitle^ message")
        var postTime : String = "123456"
        var title : String = "카톡방이름"
        var subtitle : String = "보낸사람" //카톡방 이름 없을때 null값 = 갠톡
        var message : String = "message"
        var manufacturmessage : String = "누구 입니다. 내용"

        rawmessage = OutDataQueue()

        token = rawmessage.split("^ "); // , -> ^
        /*
        postTime = token[0]
        title = if(token[1].equals(null)) //갠톡처리
            token[2]
        else
            token[1]

         */
        //postTime = token[0]
        //title = token[1]
        subtitle = token[2]
        message = token[3]

        manufacturmessage = "%s 입니다. %s".format(subtitle, message)
        //TTSQueue.add(manufacturmessage) //tm.addQueue
        print(manufacturmessage)
        return manufacturmessage
    }
}
fun main(){//방해금지 설정
    //val TTSObject = TTSManager()
    val dm = DataManager() //dm -> tm.TsPushQueue
    val tm = TTSManager()
    var message : String = "postTime^ title^ subtitle^ message"
    if (!dm.IsDistrub) {
        message = dm.InTTSQueue()
        tm.TTSPushQueue(message) // 이름변경 --> tm.TTSPushQueue
    }
}