package com.example.micromanager_datamanager

import java.util.*

class TTSManager{
    var TTSQueue : Queue<String> = LinkedList<String>() //가공된 data

    fun TTSPushQueue(message:String) : Unit{ //TTS Queue에 설정한 형식에 맞는 가공된 메세지 넣기
        TTSQueue.add(message)
    }
}

