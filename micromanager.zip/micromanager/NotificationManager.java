package com.example.micromanager;

import android.app.Notification;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;


import androidx.annotation.RequiresApi;

import java.util.LinkedList;
import java.util.Queue;

public class NotificationManager extends NotificationListenerService {
    public final static String TAG = "MyNotificationListener";

    String str="";
    Queue<String> queue = new LinkedList<>();


    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        super.onNotificationRemoved(sbn);


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);

        Notification notification = sbn.getNotification();
        Bundle extras = sbn.getNotification().extras;
        String title = extras.getString(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT);

        Icon smallIcon = notification.getSmallIcon();
        Icon largeIcon = notification.getLargeIcon();

        if(sbn.getPackageName().equals("com.kakao.talk") && !TextUtils.isEmpty(title)) {
            Log.d(TAG, "<" + subText + "> "+ title+ " : " + text);
            str = subText + "^" + title + "^" + text;
            addQueue(str);
        }
    }
    public void addQueue(String str) {
        Queue<Integer> stack = new LinkedList<>();
        queue.add(str);
    }

    public String popQueue(){
        return queue.poll();
    }

    public boolean isEmptyQueue(){
        return  queue.isEmpty();
    }


}
