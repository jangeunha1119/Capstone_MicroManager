package com.example.myapplication3

import androidx.appcompat.app.AppCompatActivity
import android.speech.tts.TextToSpeech.OnInitListener
import android.speech.tts.TextToSpeech
import android.os.Bundle
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import android.content.IntentFilter
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.graphics.Color
import android.text.Html
import android.text.Layout
import androidx.core.app.NotificationManagerCompat
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.*
import com.example.myapplication3.DataManager
import java.util.*

class MainActivity : AppCompatActivity(), OnInitListener {
    var tts: TextToSpeech? = null
    var sttr = ""
    var tab: TableLayout? = null
    val dm = DataManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        tab = findViewById<View>(R.id.tab) as TableLayout
        LocalBroadcastManager.getInstance(this).registerReceiver(onNotice, IntentFilter("Msg"))
        tts = TextToSpeech(this@MainActivity, this)
        if (!permissionGrantred()) {
            val intent = Intent(
                "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"
            )
            startActivity(intent)
        }

//        replay_button.text = ""
        val distrub_event = findViewById<ImageButton>(R.id.DistrubButton)
        val focus_event = findViewById<ImageButton>(R.id.FocusButton)
        val text_event = findViewById<ImageButton>(R.id.TextButton)
        distrub_event.setOnClickListener{
            Toast.makeText(this@MainActivity, "방해금지 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //방해금지 메소드 연결 필요
        }
        focus_event.setOnClickListener{
            Toast.makeText(this@MainActivity, "집중모드 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //집중모드 메소드 연결 필요
        }
        text_event.setOnClickListener{
            Toast.makeText(this@MainActivity, "메시지 설정 버튼이 눌렸습니다.", Toast.LENGTH_SHORT).show()
            //메시지 문구 설정 메소드 연결 필요
        }
    }

    private val onNotice: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val subText = intent.getStringExtra("subText")
            val title = intent.getStringExtra("title")
            val text = intent.getStringExtra("text")

            sttr = "$subText$title^$text"

            dm.InDataQueue("$subText","$title","$text")

            speakJust(sttr)
            val tr = TableRow(applicationContext)
            tr.layoutParams = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
            )
            val textview = TextView(applicationContext)
            textview.layoutParams = TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT,
                1.0f
            )
            textview.textSize = 20f
            textview.setTextColor(Color.parseColor("#0B0719"))
            textview.text = Html.fromHtml("$subText<br><b>$title : </b>$text")
            tr.addView(textview)
            tab!!.addView(tr)

//            var replay_button = findViewById<Button>(R.id.replay_button)
//            replay_button.text = sttr

            //다시듣기 버튼 생성
//            var replay_button = Button(this@MainActivity)
            val replay_button = findViewById<Button>(R.id.replay_button)
            val replay_text_layout = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            replay_text_layout.gravity = Gravity.CENTER
            replay_button.layoutParams = replay_text_layout

            replay_button.setText(sttr)//다시듣기 버튼의 텍스트 sttr 메세지로 변경
            tab!!.addView(replay_button)
        }
    }

    override fun onDestroy() {

        // Don't forget to shutdown!
        if (tts != null) {
            tts!!.stop()
            tts!!.shutdown()
        }
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        // TODO Auto-generated method stub
        if (status == TextToSpeech.SUCCESS) {

            // 한국어 설정
            val result = tts!!.setLanguage(Locale.KOREAN)
            // tts.setPitch(5); // set pitch level
            // tts.setSpeechRate(2); // set speech speed rate

            // 한국어가 안된다면,
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Language is not supported")
            } else {
                Log.e("TTS", "Success")
            }
        } else {
            Log.e("TTS", "Initilization Failed")
        }
    }

    private fun permissionGrantred(): Boolean {
        val sets = NotificationManagerCompat.getEnabledListenerPackages(this)
        return if (sets != null && sets.contains(packageName)) {
            true
        } else {
            false
        }
    }

    fun speakJust(text: String?) {
        // tts가 사용중이면, 말하지않는다.
        tts!!.speak(text, TextToSpeech.QUEUE_ADD, null)
    }



    companion object {
        private const val TAG = "MainActivity"
    }
}