package com.example.myapplication3


import java.util.*

class TTSManager{
    var DataQueue : Queue<String> = LinkedList<String>() //가공된 data
    var TrashQueue : Queue<String> = LinkedList<String>() //집중모드일때 쌓이고, 먼저 말해줄 data

    fun PushDataQueue(subtitle:String,message:String) : Unit{ //TTS Queue에 설정한 형식에 맞는 가공된 메세지 넣기
        DataQueue.add(message)
    }
    fun PushTrashQueue(subtitle:String,message:String) : Unit{ //Focus Queue에 설정한 형식에 맞는 가공된 메세지 넣기
        TrashQueue.add(message)
    }

    fun mySpeech(subtitle: String, message:String,flag:Int){
        //플래그에 따라 구분

    }
}

