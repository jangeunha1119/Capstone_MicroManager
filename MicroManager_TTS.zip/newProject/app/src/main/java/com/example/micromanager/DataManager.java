package com.example.micromanager;

import java.util.LinkedList;
import java.util.Queue;

public class DataManager {
    Queue<String> queue = new LinkedList<>();

    public void addQueue(String str) {
        Queue<Integer> stack = new LinkedList<>();
        queue.add(str);
    }



}
