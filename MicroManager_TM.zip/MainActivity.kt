package com.example.myapplication


import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var tts: TextToSpeech
    lateinit var TTSQueue: Queue<String>
    lateinit var FocusQueue: Queue<String>
    var modFlag: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        TTSQueue = LinkedList()


        TTSpush(DataManager.pop)
        mySpeak()


    }


    fun speech(text: String) {
        tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
            if (it == TextToSpeech.SUCCESS) {

                tts.language = Locale.KOREAN
                tts.setSpeechRate(1.0f)
                tts.speak(text.toString(), TextToSpeech.QUEUE_ADD, null)

            }
        })
    }

    fun mySpeak() {
        var topTalk = TTSQueue.poll()

        if (modFlag == 0) {
            speech(topTalk)// default
        } else if (modFlag == 1) {
            topTalk = FocusQueue.poll()
            speech(topTalk)

        } else if (modFlag == 2) {
            //아무 출력 없음
        }
    }
    private fun TTSpush(text: String) {
        TTSQueue.add(text)
    }

}