package com.example.micromanager;

import android.app.Application;

import com.kakao.sdk.common.KakaoSdk;

public class kakaoApp extends Application {
    private static kakaoApp instance;
    @Override
    public void onCreate() {
        super.onCreate();

        instance=this;


        KakaoSdk.init(this,"909e066e1deaaf9cd772858666ce7f77");
    }
}
